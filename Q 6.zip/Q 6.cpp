#include <iostream>
#include <string>

using namespace std;
	class Student {
    	int age;
    	string id;
    	string name;
    	string grade;
    	
		public:
    		void setId(string newId){
    			id=newId;
			}
			void setAge(int newAge){
				age=newAge;
			}
			void setName(string newName){
				name=newName;
			}
			void setGrade(string newGrade){
				grade=newGrade;
			}
			void displayInfo(){
				string name="Atinga",grade="",id="UEB3211122";
				int age=20;
				cout<< "Name: "<<name<<endl<< "Age: "
				<<age<<endl<< "Id: "<<id<<endl<< "grade: "
				<<grade<<endl<<endl;
			}
			
	};
	
int main(){
	string nameInput, gradeInput, idInput;
	int ageInput;
	string students[3];	
	int Age[1];
	
	Student student;
	    int choice;
    do {
        cout << "\nStudent Database Management\n";
        cout << "1. Add Student\n";
        cout << "2. List All Students\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        
        switch (choice) {
            case 1: {
                Student student1;
                cout<< "Enter student ID: ";
                cin >> idInput;
				student1.setId(idInput);
                cout<< "Enter name: ";
                cin.ignore();
                getline(cin,nameInput);
                student1.setName(nameInput);
                cout<< "Enter age: ";
                cin >> ageInput;
                student.setAge(ageInput);
                cout<< "Enter grade: ";
                cin >> gradeInput;
                student1.setGrade(gradeInput);
                
                students[0]=nameInput;
                students[1]=idInput;
                students[2]=gradeInput;
                Age[0]=ageInput;
                cout << "Student added successfully!\n";
                break;
            }
            case 2:{
            	cout<< "\nName: "<<students[0]<<endl;
            	cout<< "Id: "<<students[1]<<endl;
            	cout<< "Age: "<<Age[0]<<endl;
            	cout<< "Grade: "<<students[2]<<endl;
            	student.displayInfo();
				break;
			}
            case 3:{
            	cout<< "Exiting..."<<endl;
				break;
			}
            	
        }
    }
    while (choice!=3);
}
